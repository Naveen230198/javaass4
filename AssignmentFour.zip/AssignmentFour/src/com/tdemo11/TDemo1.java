package com.tdemo11;
public class TDemo1{
	public void met1() throws Exception {
		String str="2sdjhfgsdjhfgsdjh3";
		
		int i = Integer.parseInt(str);
	}
}